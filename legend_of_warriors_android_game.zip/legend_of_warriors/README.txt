LEGEND OF WARRIORS — Android-ready browser game prototype

PLAY:
1. Open index.html in Chrome on your Android phone.
2. Choose STORY MODE or SURVIVAL MODE.
3. Use the arrow pad to move and SWORD to attack.
4. On a computer, use WASD or arrow keys and Space to attack.

This is a playable 2D prototype, not yet an APK or a finished 3D game.
To make an installable Android APK, the next step is to package this web game
with an Android wrapper (for example, Capacitor) and build it with Android tooling.
